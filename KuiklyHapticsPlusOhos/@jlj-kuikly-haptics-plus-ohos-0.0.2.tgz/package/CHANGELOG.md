# Changelog

## 0.0.2
- 初始鸿蒙 HAR 发布（源码型）。
- 桥接名 `HRVibrateModule`：`vibrate` / `vibrateWithDuration` / `haptic` / `vibratePattern` / `play` / `cancel` / `isSupported` / `getCapabilities`。
