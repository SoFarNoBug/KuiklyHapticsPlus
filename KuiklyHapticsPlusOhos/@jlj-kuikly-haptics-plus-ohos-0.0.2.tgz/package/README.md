# @jlj/kuikly-haptics-plus-ohos

Kuikly 跨平台触感/震动模块的 **鸿蒙（OpenHarmony / HarmonyOS NEXT）** 原生实现。

- 包名：`@jlj/kuikly-haptics-plus-ohos`
- 版本：0.0.2
- Module 桥接名：`HRVibrateModule`（与 Kotlin `commonMain` 侧 `HapticsModule` 同名注册）
- 依赖：`@kuikly-open/render: 2.7.0`

## 能力映射

基于 `@ohos.vibrator`，适配 HarmonyOS NEXT / API 12+：

| 方法 | 说明 |
| --- | --- |
| `vibrate` | 默认 30ms 震动 |
| `vibrateWithDuration` | 指定时长震动（鸿蒙 time 型不支持强度，仅按 duration）|
| `haptic` | 预设触感：`light` / `medium` / `heavy` / `success` / `warning` / `error` / `selection` |
| `vibratePattern` | 自定义强弱震动序列（奇数位=震动段，偶数位=静默段），支持循环 |
| `play` | 解析 `events` 构建自定义波形（`intensity` / `frequency` 生效），`repeatCount>0` 循环 |
| `cancel` | 停止震动 |
| `isSupported` | 回调 `{supported:"1"}` |
| `getCapabilities` | 回调设备触感能力 `{supported/supportsAmplitude/supportsPredefined/supportsPattern/maxDurationMs}` |

## 集成

1. 安装依赖：`ohpm install @jlj/kuikly-haptics-plus-ohos`
2. 在 `KuiklyViewDelegate` 的 `getCustomRenderModuleCreatorRegisterMap` 中以 `"HRVibrateModule"` 为 key 注册 `KRVibrateModule`。

## 许可

MIT © 2026 jlj
